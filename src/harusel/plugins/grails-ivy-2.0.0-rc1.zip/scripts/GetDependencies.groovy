
Ant.property(environment:"env")                             
grailsHome = Ant.antProject.properties."env.GRAILS_HOME"

includeTargets << new File ( "${grailsHome}/scripts/Init.groovy" )
ivyVersion = "2.0.0-rc1"                    

target ("default": "Default task") {
    depends( configureProxy )
    dependencies()
}

target ( dependencies: "Downloads dependencies from remote repository" ) {		
	if (new File("${basedir}/ivy.xml").exists() && new File("${basedir}/ivyconf.xml").exists()) {
		ivyDeps()
	}
}

target( initIvy: "Sets up Ivy") {
    path(id:"ivy.lib.path") {
		fileset dir:"${grailsHome}/downloads/apache-ivy-${ivyVersion}/lib", includes:"*.jar"	
		fileset dir:"${grailsHome}/downloads/apache-ivy-${ivyVersion}", includes:"*.jar"			
	}
    taskdef name:'ivy-retrieve',
		    classname:'org.apache.ivy.ant.IvyRetrieve',
  			classpathref:"ivy.lib.path"
}

target ( ivyDeps : "Gets dependencies from remote repository") {
	depends(initIvy)
	
    event("IvyRetrieveStart", ["Getting Ivy dependencies"])
	ant.'ivy-retrieve'()
    event("IvyRetrieveEnd", ["Retrieved Ivy dependencies"])
}

