
class IvyGrailsPlugin {
	static final IVY_VERSION = "2.0.0-rc1"
	
	def version = "2.0.0-rc1"
    def author = 'Graeme Rocher'
    def authorEmail = 'graemerocher at yahoo.co.uk'
    def title = 'The Ivy Dependency Manager for Grails.'
    def description = '''\
Installs Ivy as a dependency manager for Grails allowing you to 
use dependency resolution in a Grails project
'''
    def documentation = 'http://grails.org/Ivy+Integration'	

}
